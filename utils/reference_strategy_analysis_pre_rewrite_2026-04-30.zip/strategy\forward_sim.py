# all simulation helpers

# imports
import numpy as np

def trade_simulation(data, indices, n_candles_forward, parameters, atr, pre_trade_metrics, direction, pip_value):

    # direction-aware callables
    _dir = 1 if direction == "long" else -1
    target_check = np.greater if direction == "long" else np.less
    stop_check = np.less if direction == "long" else np.greater
    target_idx = 2 if direction == "long" else 3
    stop_idx = 3 if direction == "long" else 2

    # unpack data ohlc + spread, parameters
    opens = data[:, 1]
    closes = data[:, 4]
    spreads = data[:, 14]

    # increment indices (trade starts on bar after setup)
    trade_indices = indices + 1
    n_setups = int(trade_indices.shape[0])

    # filter out setups that cannot span the full forward window
    valid_trade_mask = trade_indices + n_candles_forward < len(data)
    trade_indices = trade_indices[valid_trade_mask]
    m = int(trade_indices.shape[0])
    atr = atr[valid_trade_mask]

    # align bin arrays without mutating upstream metric dict
    filtered_bins = {}
    for k in ("bin_id", "spread_bin", "norm_accel_bin"):
        v = pre_trade_metrics.get(k)
        if isinstance(v, np.ndarray) and v.ndim == 1 and v.shape[0] == n_setups:
            filtered_bins[k] = v[valid_trade_mask]
        else:
            filtered_bins[k] = np.full(m, -1, dtype=np.int64)

    # create stop/target pair axis once
    stop_multiplier = np.asarray(parameters["stop_multiplier"], dtype=np.float64)
    target_multiplier = np.asarray(parameters["target_multiplier"], dtype=np.float64)
    stop_grid, target_grid = np.meshgrid(stop_multiplier, target_multiplier, indexing="ij")
    stop_pair = stop_grid.ravel()
    target_pair = target_grid.ravel()
    p = int(stop_pair.size)

    if m == 0 or p == 0:
        empty_2d = np.empty((m, p), dtype=np.float64)
        empty_i8 = np.empty((m, p), dtype=np.int8)
        return {
            "trade_idx": trade_indices.astype(np.int64, copy=False),
            "atr": atr.astype(np.float64, copy=False),
            "bin_id": filtered_bins["bin_id"].astype(np.int64, copy=False),
            "spread_bin": filtered_bins["spread_bin"].astype(np.int64, copy=False),
            "norm_accel_bin": filtered_bins["norm_accel_bin"].astype(np.int64, copy=False),
            "stop_multiplier": stop_pair,
            "target_multiplier": target_pair,
            "outcome_code": empty_i8,
            "pnl": empty_2d,
            "n_trades": int(m),
            "n_pairs": int(p),
            "n_legs": int(m * p),
        }

    # create lifespan array (2d index array of all bar indices in lifespan)
    lifespan = trade_indices[:, np.newaxis] + np.arange(n_candles_forward)

    # create entry prices, direction-agnostic. pay half of spread regardless of direction (travel from mid to bid or ask)
    entry_price = opens[trade_indices] + (spreads[trade_indices] / 2) * _dir

    # create stop, target price arrays (2d for vectorized stop/target checking along with vectorized trade checking)
    raw_delta = pre_trade_metrics["norm_price_delta"][valid_trade_mask] * atr / pip_value
    stop_price_array = entry_price[:, np.newaxis] + (raw_delta[:, np.newaxis] * stop_pair) * -1 * _dir
    target_price_array = entry_price[:, np.newaxis] + (raw_delta[:, np.newaxis] * target_pair) * _dir

    # get real OHLC stop and target prices to check
    stop_prices = data[lifespan, stop_idx]
    target_prices = data[lifespan, target_idx]
    close_prices = closes[lifespan]

    # evaluate stop and price hits. 3d boolean array
    stop_hits = stop_check(stop_prices[:, np.newaxis], stop_price_array[:, :, np.newaxis])
    target_hits = target_check(target_prices[:, np.newaxis], target_price_array[:, :, np.newaxis])

    """
    logic: axis 0 is trade list, axis 1 is flat stop/target multiplier pair (from meshgrid + ravel), axis 2 is lifespan ohlc
    """

    # find first hit of stop and target (if applicable). 
    stop_hit_times = np.where(
        stop_hits.any(axis=2),
        np.argmax(stop_hits, axis=2),
        n_candles_forward
    )
    target_hit_times = np.where(
        target_hits.any(axis=2),
        np.argmax(target_hits, axis=2),
        n_candles_forward
    )

    # outcome code: 0=timeout, 1=target, 2=stop (same-bar hits count as stop)
    timeout_mask = ~np.any(target_hits, axis=2) & ~np.any(stop_hits, axis=2)
    target_first = target_hit_times < stop_hit_times
    outcome_code = np.where(timeout_mask, 0, np.where(target_first, 1, 2)).astype(np.int8, copy=False)

    # route to the fill price for the realized leg in each (trade, pair) cell
    timeout_price_array = close_prices[:, -1][:, np.newaxis]
    exit_price = np.where(
        outcome_code == 1,
        target_price_array,
        np.where(outcome_code == 2, stop_price_array, timeout_price_array),
    )

    # per-cell exit time drives spread paid on close; timeout exits at last forward bar
    exit_time = np.where(
        outcome_code == 0,
        n_candles_forward - 1,
        np.minimum(target_hit_times, stop_hit_times),
    )
    exit_indices = trade_indices[:, np.newaxis] + exit_time
    exit_spread = spreads[exit_indices]

    # unified realized PnL per (trade, pair)
    pnl = (((exit_price - entry_price[:, np.newaxis]) * _dir) - exit_spread) * pip_value

    return {
        "trade_idx": trade_indices.astype(np.int64, copy=False),
        "atr": atr.astype(np.float64, copy=False),
        "bin_id": filtered_bins["bin_id"].astype(np.int64, copy=False),
        "spread_bin": filtered_bins["spread_bin"].astype(np.int64, copy=False),
        "norm_accel_bin": filtered_bins["norm_accel_bin"].astype(np.int64, copy=False),
        "stop_multiplier": stop_pair,
        "target_multiplier": target_pair,
        "outcome_code": outcome_code,
        "pnl": pnl,
        "n_trades": int(m),
        "n_pairs": int(p),
        "n_legs": int(m * p),
    }