# Joint quantile bins: marginal quantiles on spread_delta and norm_accel -> N x N cells.

import json
import os

import numpy as np

from strategy.risk_return_distributions import (
    risk_return_dist,
    risk_return_dist_from_codes,
    risk_return_dist_from_outcomes,
    risk_return_dist_from_pnl,
)


def quantile_binning(pre_trade_metrics, n_quantiles):
    spread_delta = np.asarray(pre_trade_metrics["spread_delta"], dtype=np.float64)
    norm_accel = np.asarray(pre_trade_metrics["norm_accel"], dtype=np.float64)

    qs = np.linspace(0.0, 1.0, n_quantiles + 1)
    s_edges = np.nanquantile(spread_delta, qs)
    n_edges = np.nanquantile(norm_accel, qs)

    for i in range(1, len(s_edges)):
        if s_edges[i] <= s_edges[i - 1]:
            s_edges[i] = np.nextafter(s_edges[i - 1], np.inf)
    for i in range(1, len(n_edges)):
        if n_edges[i] <= n_edges[i - 1]:
            n_edges[i] = np.nextafter(n_edges[i - 1], np.inf)

    s_inner = s_edges[1:-1]
    n_inner = n_edges[1:-1]

    spread_dig = np.digitize(spread_delta, s_inner, right=False)
    norm_dig = np.digitize(norm_accel, n_inner, right=False)
    spread_bin = np.clip(spread_dig, 0, n_quantiles - 1).astype(np.int64, copy=False)
    norm_bin = np.clip(norm_dig, 0, n_quantiles - 1).astype(np.int64, copy=False)

    valid = np.isfinite(spread_delta) & np.isfinite(norm_accel)
    spread_bin = np.where(valid, spread_bin, -1).astype(np.int64)
    norm_bin = np.where(valid, norm_bin, -1).astype(np.int64)
    ok = (spread_bin >= 0) & (norm_bin >= 0)
    bin_id = np.where(ok, spread_bin * n_quantiles + norm_bin, -1).astype(np.int64)

    return {
        "spread_bin": spread_bin,
        "norm_accel_bin": norm_bin,
        "bin_id": bin_id,
        "spread_edges": s_edges.tolist(),
        "norm_accel_edges": n_edges.tolist(),
        "quantile_levels": qs.tolist(),
    }


def risk_return_dist_by_bin_id(sim_results, bin_id):
    """
    For each bin_id value that appears (>= 0), slice sim_results with an internal mask
    and run risk_return_dist on that subset.

    Parameters
    ----------
    sim_results : dict
        trade_rpnl, drawdown, auto_close_rpnl — same length as bin_id.
    bin_id : array_like
        Per-row bin index (e.g. from quantile_binning); -1 rows are skipped.

    Returns
    -------
    dict[int, dict]
        Keys are bin ids; values are risk_return_dist(...) outputs.
    """
    return risk_return_dist_by_bin_groups(sim_results, prep_bin_groups(bin_id))


def prep_bin_groups(bin_id):
    """Precompute stable index groups for each non-negative bin id."""
    bid = np.asarray(bin_id, dtype=np.int64)
    groups = {}
    for c in np.unique(bid):
        if c < 0:
            continue
        idx = np.flatnonzero(bid == c)
        if idx.size:
            groups[int(c)] = idx
    return groups


def risk_return_dist_by_bin_groups(sim_results, bin_groups):
    """Run distribution summaries from precomputed bin groups."""
    out = {}
    use_realized_pnl = ("pnl" in sim_results and "outcome_code" not in sim_results)
    use_code_routing = ("outcome_code" in sim_results and "pnl" in sim_results)
    use_outcome_routing = (
        "trade_outcome" in sim_results
        and "target_rpnl" in sim_results
        and "stop_drawdown" in sim_results
        and "timeout_rpnl" in sim_results
    )

    for c, idx in bin_groups.items():
        if use_realized_pnl:
            out[int(c)] = risk_return_dist_from_pnl(sim_results["pnl"][idx])
        elif use_code_routing:
            out[int(c)] = risk_return_dist_from_codes(
                sim_results["outcome_code"][idx],
                sim_results["pnl"][idx],
            )
        elif use_outcome_routing:
            out[int(c)] = risk_return_dist_from_outcomes(
                sim_results["trade_outcome"][idx],
                sim_results["target_rpnl"][idx],
                sim_results["stop_drawdown"][idx],
                sim_results["timeout_rpnl"][idx],
            )
        else:
            cell = {
                "trade_rpnl": sim_results["trade_rpnl"][idx],
                "drawdown": sim_results["drawdown"][idx],
                "auto_close_rpnl": sim_results["auto_close_rpnl"][idx],
            }
            out[int(c)] = risk_return_dist(cell)
    return out


def export_quantile_binning(
    atr_length_dir,
    long_binning,
    short_binning,
    *,
    symbol,
    rolling_window_index,
    window_start_utc,
    window_end_utc,
    timeframe_minutes,
    n_candles_back,
    atr_length,
    n_quantiles,
    filename="quantile_edges.json",
):
    """Write quantile edge metadata + long/short marginal edges to JSON under atr_length_dir."""
    n_quantiles = int(n_quantiles)
    payload = {
        "symbol": symbol,
        "rolling_window_index": int(rolling_window_index),
        "rolling_window_start_utc": str(window_start_utc),
        "rolling_window_end_utc": str(window_end_utc),
        "timeframe_minutes": int(timeframe_minutes),
        "n_candles_back": int(n_candles_back),
        "atr_length": int(atr_length),
        "n_quantiles": n_quantiles,
        "quantile_levels": long_binning["quantile_levels"],
        "long": {
            "spread_delta_edges": long_binning["spread_edges"],
            "norm_accel_edges": long_binning["norm_accel_edges"],
        },
        "short": {
            "spread_delta_edges": short_binning["spread_edges"],
            "norm_accel_edges": short_binning["norm_accel_edges"],
        },
    }
    path = os.path.join(atr_length_dir, filename)
    with open(path, "w", encoding="utf-8") as f:
        json.dump(payload, f, indent=2)
