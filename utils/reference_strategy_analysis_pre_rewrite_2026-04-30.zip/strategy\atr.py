# ATR from OHLC only (numpy). Columns: 2=High, 3=Low, 4=Close
import numpy as np


def calculate_atr(data, indices, atr_length, pip_value):

    # ATR window uses bars [t-(atr_length-1), ..., t] and previous closes [t-atr_length, ..., t-1]
    indices = indices[indices >= atr_length]

    curr_idx = indices[:, np.newaxis] - np.arange(atr_length - 1, -1, -1)
    prev_close_idx = curr_idx - 1
    highs = data[curr_idx, 2]
    lows = data[curr_idx, 3]
    prev_closes = data[prev_close_idx, 4]

    # calculate True Range (TR), then mean along setup axis
    tr = np.maximum(
        highs - lows,
        np.maximum(
            np.abs(highs - prev_closes),
            np.abs(lows - prev_closes),
        )
    )
    atr = np.round(np.mean(tr, axis=1) * float(pip_value), 2)

    # return truncated setup indices (valid ATR only) and atr value
    return indices, atr