# Sample trade plots for validation (decoupled from vectorized sim kernels)

import numpy as np
import matplotlib.pyplot as plt
import pandas as pd

SAMPLE_PLOT_SEED = 42

_OUTCOME_LABEL = {0: "timeout", 1: "target", 2: "stop"}


def lower_middle_sorted(seq):
    """Lower-middle element of sorted unique order (median index (n-1)//2)."""
    s = sorted(seq)
    return s[(len(s) - 1) // 2]


def recompute_trade_slice(
    data,
    trade_bar,
    n_forward,
    n_candles_back,
    stop_mult,
    target_mult,
    direction,
    pip_value,
):
    """
    Recompute one trade x one (stop, target) pair: levels, exit, pnl (pips), OHLC path.
    Mirrors strategy.forward_sim.trade_simulation: stop/target distance uses the setup
    move |last setup close - first setup open| (same as strategy.metrics price_delta),
    not ATR.
    """
    _dir = 1 if direction == "long" else -1
    target_check = np.greater if direction == "long" else np.less
    stop_check = np.less if direction == "long" else np.greater
    target_idx = 2 if direction == "long" else 3
    stop_idx = 3 if direction == "long" else 2

    opens = data[:, 1]
    closes = data[:, 4]
    spreads = data[:, 14]

    setup_start = max(0, int(trade_bar) - int(n_candles_back))
    setup_idx = np.arange(setup_start, int(trade_bar), dtype=np.int64)
    lifespan = int(trade_bar) + np.arange(int(n_forward), dtype=np.int64)
    entry = float(opens[trade_bar] + (spreads[trade_bar] / 2) * _dir)
    # trade_bar is entry bar (setup completion + 1); endpoints match calculate_pre_trade_metrics
    setup_last = int(trade_bar) - 1
    i_first = int(trade_bar) - int(n_candles_back)
    raw_delta = float(np.abs(closes[setup_last] - opens[i_first]))
    stop_px = entry + (raw_delta * float(stop_mult)) * -1 * _dir
    target_px = entry + (raw_delta * float(target_mult)) * _dir

    stop_prices = data[lifespan, stop_idx]
    target_prices = data[lifespan, target_idx]
    close_path = closes[lifespan]

    stop_hits = stop_check(stop_prices, stop_px)
    target_hits = target_check(target_prices, target_px)

    if np.any(stop_hits):
        stop_hit_t = int(np.argmax(stop_hits))
    else:
        stop_hit_t = n_forward
    if np.any(target_hits):
        target_hit_t = int(np.argmax(target_hits))
    else:
        target_hit_t = n_forward

    timeout = (not np.any(target_hits)) and (not np.any(stop_hits))
    if timeout:
        oc = 0
        exit_t = n_forward - 1
        exit_px = float(close_path[-1])
    elif target_hit_t < stop_hit_t:
        oc = 1
        exit_t = target_hit_t
        exit_px = float(target_px)
    else:
        oc = 2
        exit_t = stop_hit_t
        exit_px = float(stop_px)

    exit_bar = int(trade_bar + exit_t)
    exit_spread = float(spreads[exit_bar])
    pnl_pips = ((exit_px - entry) * _dir - exit_spread) * float(pip_value)

    all_idx = np.concatenate([setup_idx, lifespan])
    times = data[all_idx, 0].astype(np.float64, copy=False)
    o = data[all_idx, 1].astype(np.float64, copy=False)
    h = data[all_idx, 2].astype(np.float64, copy=False)
    l = data[all_idx, 3].astype(np.float64, copy=False)
    c = data[all_idx, 4].astype(np.float64, copy=False)
    setup_len = int(setup_idx.size)
    exit_plot_idx = setup_len + int(exit_t)

    return {
        "entry": entry,
        "stop_px": stop_px,
        "target_px": target_px,
        "exit_t": exit_t,
        "exit_plot_idx": exit_plot_idx,
        "exit_px": exit_px,
        "exit_bar": exit_bar,
        "outcome_code": oc,
        "outcome_label": _OUTCOME_LABEL[oc],
        "pnl_pips": float(pnl_pips),
        "times": times,
        "o": o,
        "h": h,
        "l": l,
        "c": c,
        "setup_len": setup_len,
    }


def _draw_ohlc(ax, x, o, h, l, c):
    """OHLC bars with integer x positions (1 tick per bar)."""
    n = len(x)
    if n == 0:
        return
    w = 0.55

    for i in range(n):
        color = "#2ca02c" if c[i] >= o[i] else "#d62728"
        ax.plot([x[i], x[i]], [l[i], h[i]], color="0.15", linewidth=0.9, zorder=1)
        y0, y1 = (o[i], c[i]) if c[i] >= o[i] else (c[i], o[i])
        ax.add_patch(
            plt.Rectangle(
                (x[i] - w / 2, y0),
                w,
                max(y1 - y0, 1e-12),
                facecolor=color,
                edgecolor="0.15",
                linewidth=0.4,
                zorder=2,
            )
        )

def _plot_one_panel(ax, geo, *, title_detail):
    times = np.asarray(geo["times"])
    x = np.arange(times.size, dtype=np.int64)
    _draw_ohlc(ax, x, geo["o"], geo["h"], geo["l"], geo["c"])

    ax.axhline(geo["entry"], color="C0", linewidth=1.0, label="entry", zorder=3)
    ax.axhline(geo["stop_px"], color="C3", linestyle="--", linewidth=1.0, label="stop", zorder=3)
    ax.axhline(geo["target_px"], color="C2", linestyle="--", linewidth=1.0, label="target", zorder=3)

    boundary_x = geo["setup_len"] - 0.5
    ax.axvline(boundary_x, color="C4", linestyle=":", linewidth=1.2, label="setup->lifespan", zorder=4)

    xt = int(geo["exit_plot_idx"])
    ax.scatter(
        [xt],
        [geo["exit_px"]],
        s=80,
        zorder=5,
        color="black",
        marker="o",
        label=f"exit ({geo['outcome_label']})",
    )

    labels = pd.to_datetime(times, unit="s", utc=True).strftime("%m-%d %H:%M")
    ax.set_xticks(x)
    ax.set_xticklabels(labels, rotation=35, ha="right", fontsize=7)

    ax.set_title(title_detail, fontsize=10)
    ax.set_ylabel("price")
    ax.legend(loc="upper left", fontsize=7)
    ax.grid(True, alpha=0.25)


def plot_sample_long_short_png(
    data,
    *,
    pip_value,
    n_quantiles,
    n_forward,
    atr_length,
    long_sim,
    short_sim,
    long_row,
    long_pair,
    short_row,
    short_pair,
    symbol,
    window_start_date,
    window_end_date,
    timeframe_minutes,
    n_candles_back,
    out_path,
    plot_rng_seed,
):
    """
    One figure: long | short subplots. Geometry recomputed per side (minimal coupling to sim).
    Skipping empty sides is handled by the caller.
    """
    tb_l = int(long_sim["trade_idx"][long_row])
    sm_l = float(long_sim["stop_multiplier"][long_pair])
    tm_l = float(long_sim["target_multiplier"][long_pair])
    bid_l = int(long_sim["bin_id"][long_row])
    sb_l = int(long_sim["spread_bin"][long_row])
    nb_l = int(long_sim["norm_accel_bin"][long_row])

    tb_s = int(short_sim["trade_idx"][short_row])
    sm_s = float(short_sim["stop_multiplier"][short_pair])
    tm_s = float(short_sim["target_multiplier"][short_pair])
    bid_s = int(short_sim["bin_id"][short_row])
    sb_s = int(short_sim["spread_bin"][short_row])
    nb_s = int(short_sim["norm_accel_bin"][short_row])

    geo_l = recompute_trade_slice(
        data, tb_l, n_forward, n_candles_back, sm_l, tm_l, "long", pip_value
    )
    geo_s = recompute_trade_slice(
        data, tb_s, n_forward, n_candles_back, sm_s, tm_s, "short", pip_value
    )

    fig, axes = plt.subplots(1, 2, figsize=(16, 6), dpi=150, constrained_layout=True)

    suptitle = (
        f"{symbol}  |  window {window_start_date}–{window_end_date}  |  {timeframe_minutes}m  |  L{n_candles_back}\n"
        f"ATR={atr_length}  |  F={n_forward}  |  n_quantiles={n_quantiles}  |  rng_seed={plot_rng_seed}"
    )
    fig.suptitle(suptitle, fontsize=11)

    detail_l = (
        f"LONG bin_id={bid_l}  spread_bin={sb_l}  norm_bin={nb_l}\n"
        f"stop×target={sm_l}×{tm_l}  | {_OUTCOME_LABEL[geo_l['outcome_code']]}  |  "
        f"pnl={geo_l['pnl_pips']:.2f} pips  |  sim pnl={float(long_sim['pnl'][long_row, long_pair]):.2f}"
    )
    detail_s = (
        f"SHORT  bin_id={bid_s}  spread_bin={sb_s}  norm_bin={nb_s}\n"
        f"stop×target={sm_s}×{tm_s}  |  {_OUTCOME_LABEL[geo_s['outcome_code']]}  |  "
        f"pnl={geo_s['pnl_pips']:.2f} pips  |  sim pnl={float(short_sim['pnl'][short_row, short_pair]):.2f}"
    )

    _plot_one_panel(axes[0], geo_l, title_detail=detail_l)
    _plot_one_panel(axes[1], geo_s, title_detail=detail_s)

    fig.savefig(out_path)
    plt.close(fig)
