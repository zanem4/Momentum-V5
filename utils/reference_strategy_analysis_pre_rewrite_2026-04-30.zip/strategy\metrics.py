# pre-trade metrics

# imports
import numpy as np

def calculate_pre_trade_metrics(data, indices, atr, pip_value, n_candles_back):
    
    # unpack ohlc
    opens = data[:, 1]
    highs = data[:, 2]
    lows = data[:, 3]
    closes = data[:, 4]
    volumes = data[:, 5]
    spreads = data[:, 14]

    # truncate setups that don't have sufficient data to calculate metrics on
    # setup window is [t-(n_candles_back-1), ..., t]
    valid_indices = indices >= (n_candles_back - 1)
    indices = indices[valid_indices]
    atr = atr[valid_indices]

    # build 2d index array over setup candles [t-(n-1), ..., t]
    pre_trade_indices = indices[:, np.newaxis] - np.arange(n_candles_back - 1, -1, -1)

    # find velocity (n_candles_back - 1 data points)
    velocities = np.diff(closes[pre_trade_indices], axis=1)
    velo_avg = np.mean(velocities, axis=1)

    # find acceleration (n_candles_back - 2 data points, taken from velocities), then normalize to ATR
    accelerations = np.diff(velocities, axis=1)
    accel_avg = np.mean(accelerations, axis=1)
    norm_accel = np.round(accel_avg / (atr / pip_value), 5)

    # find price delta across setup window endpoints, then normalize to ATR
    first_point = opens[indices - (n_candles_back - 1)]
    second_point = closes[indices]
    price_delta = np.abs(second_point - first_point)
    norm_delta = np.round(price_delta / (atr / pip_value), 5)

    # find spread to price delta (safe divide when price_delta == 0)
    spread_ratio = np.divide(
        spreads[indices],
        price_delta,
        out=np.full(price_delta.shape, np.nan, dtype=np.float64),
        where=price_delta != 0,
    )
    spread_delta = np.round(spread_ratio, 5)

    # convert setup indices to UNIX timestamp
    setup_timestamps = data[indices, 0]

    # return metrics
    return indices, atr, {"setup_timestamps": setup_timestamps, "norm_accel": norm_accel, "norm_price_delta": norm_delta, "spread_delta": spread_delta}