# execution
# CSV/Parquet indexing key
"""
Index 0: Time
Index 1: Open
Index 2: High
Index 3: Low
Index 4: Close
Index 5: Volume
Index 6: Bid Open
Index 7: Bid High
Index 8: Bid Low
Index 9: Bid Close
Index 10: Ask Open
Index 11: Ask High
Index 12: Ask Low
Index 13: Ask Close
Index 14: Spread Close
"""

# module imports
import sys
import os
import json
import numpy as np
import pandas as pd
import time
import pyarrow.parquet as pq
import random
import datetime
import shutil

# file imports
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from utils.composite_candle import composite_candle
from strategy.structure import structure
from strategy.atr import calculate_atr
from strategy.metrics import calculate_pre_trade_metrics
from strategy.quantile_binning import (
    export_quantile_binning,
    prep_bin_groups,
    quantile_binning,
)
from strategy.forward_sim import trade_simulation
from strategy.prep_export import build_forward_rows_from_sim, write_rows_to_parquet
from strategy.plotter import (
    SAMPLE_PLOT_SEED,
    lower_middle_sorted,
    plot_sample_long_short_png,
)
_REPO_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


def equal_overlap_rolling_windows(m1_data, n_windows):
    """
    n equal-duration half-open UTC windows on column 0 (time in unix seconds).

    Symmetric 50% overlap between neighbours: the second half of window i is
    exactly the first half of window i+1. Equivalently step = L/2 and
    L = 2*T/(n+1) so the last window ends at the same exclusive end as the span
    [t_min, t_max] (with t_max inclusive extended by +1s for half-open cuts).

    Row counts per window can differ; boundaries are pure time.

    Returns:
      starts_unix (n,), ends_unix (n,) float64
      starts_utc, ends_utc: pd.Timestamp UTC length n
      mask (n_rows, n) bool — mask[k, i] True if row k falls in window i
    """
    if m1_data.size == 0:
        raise ValueError("m1_data is empty")

    n = int(n_windows)
    if n < 1:
        raise ValueError("number_rolling_windows must be >= 1")

    t_col = m1_data[:, 0].astype(np.float64, copy=False)
    t_min = float(t_col.min())
    t_max = float(t_col.max())
    t0 = pd.Timestamp(t_min, unit='s', tz='UTC')
    t1_excl = pd.Timestamp(t_max, unit='s', tz='UTC') + pd.Timedelta(seconds=1)
    T = t1_excl - t0
    t_sec = T.total_seconds()

    if n == 1:
        l_sec = t_sec
        step_sec = 0.0
    else:
        l_sec = (2.0 * t_sec) / (n + 1)
        step_sec = l_sec / 2.0

    t0_unix = t0.timestamp()
    i = np.arange(n, dtype=np.float64)
    starts_unix = t0_unix + i * step_sec
    ends_unix = starts_unix + l_sec

    starts_utc = pd.to_datetime(starts_unix, unit='s', utc=True)
    ends_utc = pd.to_datetime(ends_unix, unit='s', utc=True)

    tc = t_col[:, np.newaxis]
    su = starts_unix[np.newaxis, :]
    eu = ends_unix[np.newaxis, :]
    mask = (tc >= su) & (tc < eu)
    return starts_unix, ends_unix, starts_utc, ends_utc, mask

# begin flow
def main():

    # load parameters
    with open(os.path.join(_REPO_ROOT, 'utils', 'parameters.json'), 'r') as f:
        parameters = json.load(f)
    
    # search for parquet in data path
    parquet_files = [f for f in os.listdir(parameters['data_path']) if f.endswith('.parquet')]
    if len(parquet_files) == 0:
        raise FileNotFoundError(f"No parquet files found in {parameters['data_path']}")
    
    # get specific file
    if parameters['use_random_asset']:
        asset = random.choice(parquet_files)
        symbol = asset.split('.')[0]
    else:
        symbol = f"{parameters['base']}_{parameters['quote']}"
        if f"{symbol}.parquet" not in parquet_files:
            raise FileNotFoundError(f"Asset {symbol} not found in {parameters['data_path']}")
        asset = f"{symbol}.parquet"
    print(f"Using asset: {symbol}")

    # load parquet file & truncate to [start_date, end_date] inclusive (UTC calendar days)
    m1_data = pq.read_table(os.path.join(parameters['data_path'], asset)).to_pandas().to_numpy()
    start_ts = pd.Timestamp(parameters['start_date'], tz='UTC').timestamp()
    end_ts_exclusive = (pd.Timestamp(parameters['end_date'], tz='UTC') + pd.Timedelta(days=1)).timestamp()
    t = m1_data[:, 0].astype(np.float64, copy=False)
    m1_data = m1_data[(t >= start_ts) & (t < end_ts_exclusive)]
    if m1_data.size == 0:
        raise ValueError("No m1 rows after date range filter.")
    n_windows = parameters['number_rolling_windows']
    su, eu, su_ts, eu_ts, win_mask = equal_overlap_rolling_windows(m1_data, n_windows)
    m1_by_window = [m1_data[win_mask[:, i]] for i in range(n_windows)]
    print(
        f"Rolling windows (UTC): n={n_windows}, 50% neighbour overlap, "
        f"first [{su_ts[0]} .. {eu_ts[0]}), "
        f"rows per window={[int(win_mask[:, i].sum()) for i in range(n_windows)]}",
    )

    # get pip value for asset
    pip_value = parameters['pip_value_by_symbol'][symbol]

    # performance parameters (bench_elapsed excludes plotting I/O)
    total_trades_simulated = 0
    bench_elapsed = 0.0
    median_atr = lower_middle_sorted(parameters["atr_length"])
    median_F = lower_middle_sorted(parameters["n_candles_forward"])

    # make general output directory
    output_dir = os.path.join(_REPO_ROOT, 'output', f"{symbol}_{parameters['start_date']}_{parameters['end_date']}")
    os.makedirs(output_dir, exist_ok=True)

    # make sample images folder (once)
    sample_images_dir = os.path.join(output_dir, "sample_images")
    os.makedirs(sample_images_dir, exist_ok=True)
    window_metric_rows = []

    # iterate by rolling window
    for i, window in enumerate(m1_by_window):

        # print rolling window information
        print(f"Processing rolling window {i+1} of {n_windows}")
        print(f"Window start/end: {su_ts[i]} / {eu_ts[i]}")

        # make directory for ith rolling window
        window_start_date = su_ts[i].strftime("%Y-%m-%d")
        window_end_date = eu_ts[i].strftime("%Y-%m-%d")
        window_dir = os.path.join(output_dir, f"window_{window_start_date}_{window_end_date}")
        os.makedirs(window_dir, exist_ok=True)
        split_total_trades = []
        split_trades_per_sec = []
        split_sec_per_trade = []

        # iterate by timeframe
        for tf in parameters['timeframe_minutes']:

            # make composite candles. for timeframes
            composite_candles, m1_indices = composite_candle(window, tf)
            print(f"Number of {tf}m candles: {len(composite_candles)}")

            # make directory for ith timeframe
            timeframe_dir = os.path.join(window_dir, f"{tf}m")
            os.makedirs(timeframe_dir, exist_ok=True)

            # iterate by n_candles_back. structure detection
            for n_candles_back in parameters['n_candles_back']:

                # find setups
                long_indices = structure(composite_candles, n_candles_back, "long")
                short_indices = structure(composite_candles, n_candles_back, "short")
                print(f"Number of {n_candles_back}-bar setups found: {len(long_indices) + len(short_indices)}")

                # make directory for ith n_candles_back
                n_candles_back_dir = os.path.join(timeframe_dir, f"L{n_candles_back}")

                # iterate by atr_length. volatility and metrics calculation for testing
                for atr_length in parameters['atr_length']:
                    split_trades_before = total_trades_simulated
                    t_work = time.perf_counter()

                    # calculate atr at setups only
                    long_indices, long_atr = calculate_atr(composite_candles, long_indices, atr_length, pip_value)
                    short_indices, short_atr = calculate_atr(composite_candles, short_indices, atr_length, pip_value)

                    # calculate pre-trade metrics
                    long_indices, long_atr, long_pre_trade_metrics = calculate_pre_trade_metrics(
                        composite_candles, long_indices, long_atr, pip_value, n_candles_back
                    )
                    short_indices, short_atr, short_pre_trade_metrics = calculate_pre_trade_metrics(
                        composite_candles, short_indices, short_atr, pip_value, n_candles_back
                    )

                    # N x N joint quantile cells; bin columns slice with simulate_trades mask
                    n_quantiles = parameters["n_quantiles"]
                    lb = quantile_binning(long_pre_trade_metrics, n_quantiles)
                    sb = quantile_binning(short_pre_trade_metrics, n_quantiles)
                    for _name in ("spread_bin", "norm_accel_bin", "bin_id"):
                        long_pre_trade_metrics[_name] = lb[_name]
                        short_pre_trade_metrics[_name] = sb[_name]

                    # make directory for ith atr_length, export quantile data as a result
                    atr_length_dir = os.path.join(n_candles_back_dir, f"ATR_{atr_length}")
                    os.makedirs(atr_length_dir, exist_ok=True)
                    export_quantile_binning(
                        atr_length_dir,
                        lb,
                        sb,
                        symbol=symbol,
                        rolling_window_index=i,
                        window_start_utc=su_ts[i],
                        window_end_utc=eu_ts[i],
                        timeframe_minutes=tf,
                        n_candles_back=n_candles_back,
                        atr_length=atr_length,
                        n_quantiles=n_quantiles,
                    )

                    # iterate by n_candles_forward. trade simulation
                    sim_by_forward = {}
                    for n_candles_forward in parameters["n_candles_forward"]:
                        # full trade simulation first, then aggregate/export in a second pass
                        long_sim = trade_simulation(
                            composite_candles,
                            long_indices,
                            n_candles_forward,
                            parameters,
                            long_atr,
                            long_pre_trade_metrics,
                            "long",
                            pip_value,
                        )
                        short_sim = trade_simulation(
                            composite_candles,
                            short_indices,
                            n_candles_forward,
                            parameters,
                            short_atr,
                            short_pre_trade_metrics,
                            "short",
                            pip_value,
                        )
                        sim_by_forward[int(n_candles_forward)] = (
                            long_sim,
                            short_sim,
                            prep_bin_groups(long_sim["bin_id"]),
                            prep_bin_groups(short_sim["bin_id"]),
                        )

                        # track total simulated legs for performance statistics
                        total_trades_simulated += long_sim["n_legs"] + short_sim["n_legs"]

                    forward_rows_by_path = {}
                    for n_candles_forward, (long_sim, short_sim, long_bin_groups, short_bin_groups) in sim_by_forward.items():
                        common_context = {}
                        forward_export_rows = []
                        forward_export_rows.extend(
                            build_forward_rows_from_sim(
                                long_sim,
                                direction="long",
                                bin_groups=long_bin_groups,
                                n_quantiles=n_quantiles,
                                common_context=common_context,
                            )
                        )
                        forward_export_rows.extend(
                            build_forward_rows_from_sim(
                                short_sim,
                                direction="short",
                                bin_groups=short_bin_groups,
                                n_quantiles=n_quantiles,
                                common_context=common_context,
                            )
                        )
                        forward_path = os.path.join(atr_length_dir, f"F{n_candles_forward}.parquet")
                        forward_rows_by_path[forward_path] = forward_export_rows

                    for forward_path, forward_export_rows in forward_rows_by_path.items():
                        write_rows_to_parquet(
                            forward_export_rows,
                            forward_path,
                            compression="snappy",
                        )

                    split_elapsed = time.perf_counter() - t_work
                    bench_elapsed += split_elapsed
                    split_trades = total_trades_simulated - split_trades_before
                    if split_elapsed > 0 and split_trades > 0:
                        split_total_trades.append(float(split_trades))
                        split_trades_per_sec.append(float(split_trades / split_elapsed))
                        split_sec_per_trade.append(float(split_elapsed / split_trades))

                    if atr_length == median_atr and median_F in sim_by_forward:
                        long_sim_p, short_sim_p, _, _ = sim_by_forward[median_F]
                        if long_sim_p["n_trades"] > 0 and short_sim_p["n_trades"] > 0:
                            plot_rng_seed = (
                                SAMPLE_PLOT_SEED
                                + i * 1_000_003
                                + int(tf) * 10_007
                                + int(n_candles_back) * 97
                            )
                            rng = np.random.default_rng(plot_rng_seed)
                            i_long = int(rng.integers(0, long_sim_p["n_trades"]))
                            j_long = int(rng.integers(0, long_sim_p["n_pairs"]))
                            i_short = int(rng.integers(0, short_sim_p["n_trades"]))
                            j_short = int(rng.integers(0, short_sim_p["n_pairs"]))
                            sample_name = (
                                f"{window_start_date}_{window_end_date}__{tf}m__L{n_candles_back}.png"
                            )
                            sample_path = os.path.join(sample_images_dir, sample_name)
                            plot_sample_long_short_png(
                                composite_candles,
                                pip_value=pip_value,
                                n_quantiles=n_quantiles,
                                n_forward=int(median_F),
                                atr_length=int(median_atr),
                                long_sim=long_sim_p,
                                short_sim=short_sim_p,
                                long_row=i_long,
                                long_pair=j_long,
                                short_row=i_short,
                                short_pair=j_short,
                                symbol=symbol,
                                window_start_date=window_start_date,
                                window_end_date=window_end_date,
                                timeframe_minutes=int(tf),
                                n_candles_back=int(n_candles_back),
                                out_path=sample_path,
                                plot_rng_seed=int(plot_rng_seed),
                            )
                    
                    # print in-line statistics
                    print(f"Total trades simulated (so far): {total_trades_simulated}")
                    print(f"Bench time (so far, excl. plots): {bench_elapsed:0.5f} seconds")
                    if bench_elapsed > 0:
                        print(f"Trades per second (bench): {total_trades_simulated / bench_elapsed:0.2f}")
                        print(f"Time per trade (bench): {bench_elapsed / total_trades_simulated:0.8f} seconds")

        # per-window rollup: averages across all splits in this rolling window
        if split_total_trades:
            window_metric_rows.append(
                {
                    "window_index": int(i),
                    "window_start": window_start_date,
                    "window_end": window_end_date,
                    "avg_total_trades": float(np.mean(split_total_trades)),
                    "avg_trades_per_sec": float(np.mean(split_trades_per_sec)),
                    "avg_sec_per_trade": float(np.mean(split_sec_per_trade)),
                    "split_count": int(len(split_total_trades)),
                }
            )
        else:
            window_metric_rows.append(
                {
                    "window_index": int(i),
                    "window_start": window_start_date,
                    "window_end": window_end_date,
                    "avg_total_trades": 0.0,
                    "avg_trades_per_sec": 0.0,
                    "avg_sec_per_trade": 0.0,
                    "split_count": 0,
                }
            )


    # run statistics
    print(f"\n\nTotal trades simulated: {total_trades_simulated}")
    print(f"Bench time (excl. plots): {bench_elapsed:0.5f} seconds")
    if bench_elapsed > 0:
        print(f"Trades per second (bench): {total_trades_simulated / bench_elapsed:0.2f}")
        print(f"Time per trade (bench): {bench_elapsed / total_trades_simulated:0.8f} seconds")

    # final per-window benchmark export
    metrics_txt_path = os.path.join(output_dir, "rolling_window_bench_metrics.txt")
    cumulative_trades_per_sec = (
        float(total_trades_simulated / bench_elapsed)
        if bench_elapsed > 0
        else float("nan")
    )
    cumulative_sec_per_trade = (
        float(bench_elapsed / total_trades_simulated)
        if total_trades_simulated > 0
        else float("nan")
    )
    with open(metrics_txt_path, "w", encoding="utf-8") as f:
        f.write("Per-window metrics (averaged across splits)\n")
        f.write("window_index | window_start | window_end | split_count | avg_total_trades | avg_trades_per_sec | avg_sec_per_trade\n")
        for row in window_metric_rows:
            f.write(
                f"{row['window_index']} | {row['window_start']} | {row['window_end']} | "
                f"{row['split_count']} | {row['avg_total_trades']:.2f} | "
                f"{row['avg_trades_per_sec']:.2f} | {row['avg_sec_per_trade']:.8f}\n"
            )
        f.write("\nCumulative benchmark stats\n")
        f.write(f"total_trades_simulated: {total_trades_simulated}\n")
        f.write(f"bench_time_excl_plots_sec: {bench_elapsed:.5f}\n")
        f.write(f"trades_per_second_bench: {cumulative_trades_per_sec:.2f}\n")
        f.write(f"seconds_per_trade_bench: {cumulative_sec_per_trade:.8f}\n")

    # Save a copy of parameters.json to the output directory for provenance
    try:
        src_parameters_path = os.path.join("utils", "parameters.json")
        dst_parameters_path = os.path.join(output_dir, "parameters.json")
        shutil.copyfile(src_parameters_path, dst_parameters_path)
    except Exception as e:
        print(f"Warning: Could not copy parameters.json to output directory: {e}")
    
if __name__ == "__main__":
    main()