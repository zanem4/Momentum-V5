# return distribution metrics. mean, median, variance, n-count, p25/p75, and group data accordingly

# imports
import numpy as np

MIN_BIN_SAMPLE_COUNT = 30


def _safe_summary(arr, min_sample_count=MIN_BIN_SAMPLE_COUNT):
    """Summary stats with finite-value guards for sparse slices."""
    a = np.asarray(arr, dtype=np.float64)
    finite = np.isfinite(a)
    n = int(np.sum(finite))

    if n == 0:
        return {
            "mean": np.nan,
            "median": np.nan,
            "variance": np.nan,
            "n_count": 0,
            "p25": np.nan,
            "p75": np.nan,
        }

    # keep row but blank summary metrics for low-sample bins
    if n < int(min_sample_count):
        return {
            "mean": np.nan,
            "median": np.nan,
            "variance": np.nan,
            "n_count": n,
            "p25": np.nan,
            "p75": np.nan,
        }

    x = a[finite]
    mean = np.round(np.mean(x), 2)
    median = np.round(np.median(x), 2)
    p25 = np.round(np.percentile(x, 25), 3)
    p75 = np.round(np.percentile(x, 75), 3)
    variance = np.round(np.var(x, ddof=1), 3) if n >= 2 else np.nan

    return {
        "mean": mean,
        "median": median,
        "variance": variance,
        "n_count": n,
        "p25": p25,
        "p75": p75,
    }


def risk_return_dist(sim_results):

    real_profit = sim_results['trade_rpnl']
    real_drawdown = sim_results['drawdown']
    auto_close_rpnl = sim_results['auto_close_rpnl']

    profit_dict = _safe_summary(real_profit)
    drawdown_dict = _safe_summary(real_drawdown)
    auto_close_dict = _safe_summary(auto_close_rpnl)

    return {"profit": profit_dict, "drawdown": drawdown_dict, "auto_close": auto_close_dict}


def risk_return_dist_from_outcomes(trade_outcome, target_rpnl, stop_drawdown, timeout_rpnl):
    """
    Route dense per-trade leg arrays by outcome, then summarize only relevant values.
    """
    o = np.asarray(trade_outcome)
    t = np.asarray(target_rpnl, dtype=np.float64)
    s = np.asarray(stop_drawdown, dtype=np.float64)
    c = np.asarray(timeout_rpnl, dtype=np.float64)

    profit_dict = _safe_summary(t[o == "target"])
    drawdown_dict = _safe_summary(s[o == "stop"])
    auto_close_dict = _safe_summary(c[o == "timeout"])
    return {"profit": profit_dict, "drawdown": drawdown_dict, "auto_close": auto_close_dict}


def risk_return_dist_from_codes(outcome_code, pnl):
    """
    Route per-trade pnl by compact outcome code.

    outcome_code mapping:
      0 -> timeout
      1 -> target
      2 -> stop
    """
    oc = np.asarray(outcome_code, dtype=np.int8)
    x = np.asarray(pnl, dtype=np.float64)

    profit_dict = _safe_summary(x[oc == 1])
    drawdown_dict = _safe_summary(x[oc == 2])
    auto_close_dict = _safe_summary(x[oc == 0])
    return {"profit": profit_dict, "drawdown": drawdown_dict, "auto_close": auto_close_dict}


def risk_return_dist_from_pnl(pnl):
    """
    Summary metrics on realized pnl only.
    """
    x = np.asarray(pnl, dtype=np.float64)
    return {"pnl": _safe_summary(x)}