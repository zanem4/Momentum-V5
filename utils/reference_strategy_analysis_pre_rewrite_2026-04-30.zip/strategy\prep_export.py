# Flatten nested dicts for export (e.g. Parquet rows / JSON) without mutating inputs.

from collections.abc import Mapping

import numpy as np
import pandas as pd

from strategy.quantile_binning import risk_return_dist_by_bin_groups


def flatten_dict(d, parent_key="", sep="_"):
    """
    Return a new one-level dict: nested keys become ``parent_child_grandchild``.

    - Does **not** mutate ``d``.
    - Dict values are merged recursively; other values are leaves.
    - ``numpy.ndarray`` → ``.tolist()``; numpy scalars → ``.item()`` when possible.

    Examples
    --------
    >>> flatten_dict({"a": {"b": 1, "c": {"d": 2}}})
    {'a_b': 1, 'a_c_d': 2}
    """
    if not isinstance(d, Mapping):
        raise TypeError(f"flatten_dict expected mapping, got {type(d).__name__}")

    out = {}
    for k, v in d.items():
        sk = str(k)
        new_key = f"{parent_key}{sep}{sk}" if parent_key else sk
        if isinstance(v, Mapping):
            out.update(flatten_dict(v, new_key, sep=sep))
        elif isinstance(v, np.ndarray):
            out[new_key] = v.tolist()
        elif isinstance(v, np.generic):
            out[new_key] = v.item()
        else:
            out[new_key] = v
    return out


def flatten_dist_by_bin(dist_by_bin, sep="_"):
    """
    Turn ``{bin_id: risk_return_dist_output, ...}`` into a list of flat row dicts.

    Each row is ``{"bin_id": int, **flatten_dict(dist)}`` so bin dimension is explicit
    and metrics stay unique (e.g. ``profit_mean``, not ``0_profit_mean`` on the row).

    Parameters
    ----------
    dist_by_bin : dict
        Keys are bin ids (int); values are nested dicts (e.g. profit/drawdown/auto_close).
    sep : str
        Separator for nested keys inside each bin's flattened metrics.
    """
    if not isinstance(dist_by_bin, Mapping):
        raise TypeError(f"flatten_dist_by_bin expected mapping, got {type(dist_by_bin).__name__}")

    rows = []
    for bin_id, dist in dist_by_bin.items():
        if not isinstance(dist, Mapping):
            raise TypeError(f"dist for bin {bin_id!r} must be a mapping, got {type(dist).__name__}")
        row = {"bin_id": int(bin_id)}
        row.update(flatten_dict(dist, parent_key="", sep=sep))
        rows.append(row)
    return rows


def merge_export_context(rows, extra, *, n_quantiles=None):
    """
    Copy each row dict and merge ``extra`` (e.g. stop_multiplier, direction).

    If ``n_quantiles`` is set, add ``spread_bin`` and ``norm_accel_bin`` from
    ``bin_id`` (same encoding as ``quantile_binning``: ``bin_id = spread_bin * n + norm_bin``).
    """
    out = []
    nq = int(n_quantiles) if n_quantiles is not None else None
    for row in rows:
        r = dict(row)
        r.update(extra)
        if nq is not None and nq >= 1:
            bid = r.get("bin_id")
            if isinstance(bid, int) and bid >= 0:
                r["spread_bin"] = bid // nq
                r["norm_accel_bin"] = bid % nq
        out.append(r)
    return out


def build_forward_rows_from_sim(
    sim_results,
    *,
    direction,
    bin_groups,
    n_quantiles,
    common_context,
):
    """
    Build flat export rows from compact sim outputs (m x P) for one direction.
    """
    if sim_results["n_trades"] == 0 or sim_results["n_pairs"] == 0 or not bin_groups:
        return []

    rows = []
    pair_count = int(sim_results["n_pairs"])
    pnl_2d = sim_results["pnl"]
    stop_pair = sim_results["stop_multiplier"]
    target_pair = sim_results["target_multiplier"]

    for pair_idx in range(pair_count):
        pair_results = {
            "pnl": pnl_2d[:, pair_idx],
        }
        dist_by_bin = risk_return_dist_by_bin_groups(pair_results, bin_groups)
        dist_rows = flatten_dist_by_bin(dist_by_bin)

        pair_context = {
            **common_context,
            "stop_multiplier": float(stop_pair[pair_idx]),
            "target_multiplier": float(target_pair[pair_idx]),
            "direction": direction,
        }
        rows.extend(
            merge_export_context(
                dist_rows,
                pair_context,
                n_quantiles=n_quantiles,
            )
        )
    return rows


def write_rows_to_parquet(rows, path, *, compression="snappy"):
    """Write rows to parquet if non-empty."""
    if not rows:
        return False
    df = pd.DataFrame(rows)
    df.to_parquet(path, index=False, engine="pyarrow", compression=compression)
    return True
