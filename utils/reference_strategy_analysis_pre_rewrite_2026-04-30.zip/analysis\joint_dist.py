# Joint distribution heatmaps for spread_delta and norm_accel quantile bins.

import json
import os
import re
import sys
from collections import defaultdict

import matplotlib.pyplot as plt
from matplotlib.colors import Normalize, TwoSlopeNorm
import numpy as np
import pandas as pd
import pyarrow.parquet as pq


VALID_DIMENSIONS = {"L_value", "ATR_value", "F_value"}
METRICS = ("pnl_mean", "pnl_median", "pnl_stdev")
DIRECTIONS = ("long", "short", "composite")


def _repo_root():
    return os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


def _load_parameters():
    path = os.path.join(_repo_root(), "utils", "parameters.json")
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)


def _parquet_paths(run_dir):
    paths = []
    for root, _, files in os.walk(run_dir):
        parts = set(os.path.normpath(root).split(os.sep))
        if not any(part.startswith("window_") for part in parts):
            continue
        for name in files:
            if name.startswith("F") and name.endswith(".parquet"):
                paths.append(os.path.join(root, name))
    return sorted(paths)


def _parse_path_metadata(path, run_dir):
    rel = os.path.relpath(path, run_dir)
    parts = rel.split(os.sep)

    window_part = next(part for part in parts if part.startswith("window_"))
    window_label = window_part.replace("window_", "")

    timeframe_part = next(part for part in parts if part.endswith("m"))
    l_part = next(part for part in parts if re.fullmatch(r"L\d+", part))
    atr_part = next(part for part in parts if part.startswith("ATR_"))
    f_part = os.path.splitext(os.path.basename(path))[0]

    return {
        "rolling_window": window_label,
        "timeframe": int(timeframe_part[:-1]),
        "L_value": int(l_part[1:]),
        "ATR_value": int(atr_part.replace("ATR_", "")),
        "F_value": int(f_part[1:]),
    }


def _new_accumulator():
    return {
        "raw_n_count": 0.0,
        "mean_weight": 0.0,
        "mean_sum": 0.0,
        "median_weight": 0.0,
        "median_sum": 0.0,
        "variance_weight": 0.0,
        "variance_mean_sum": 0.0,
        "variance_second_sum": 0.0,
    }


def _update_accumulator(acc, row):
    n = float(row["pnl_n_count"])
    if not np.isfinite(n) or n <= 0:
        return

    acc["raw_n_count"] += n
    mean = float(row["pnl_mean"])
    median = float(row["pnl_median"])
    variance = float(row["pnl_variance"])

    if np.isfinite(mean):
        acc["mean_weight"] += n
        acc["mean_sum"] += mean * n

    if np.isfinite(median):
        acc["median_weight"] += n
        acc["median_sum"] += median * n

    if np.isfinite(mean) and np.isfinite(variance) and n >= 2:
        acc["variance_weight"] += n
        acc["variance_mean_sum"] += mean * n
        acc["variance_second_sum"] += (n - 1.0) * variance + n * mean * mean


def _finalize_accumulators(accumulators, packet):
    rows = []
    stop_band = ",".join(str(float(x)) for x in packet["stop_band"])
    target_band = ",".join(str(float(x)) for x in packet["target_band"])

    for key, acc in accumulators.items():
        timeframe, direction, window, dim_value, spread_bin, norm_accel_bin = key

        mean_n = acc["mean_weight"]
        median_n = acc["median_weight"]
        variance_n = acc["variance_weight"]

        pnl_mean = acc["mean_sum"] / mean_n if mean_n > 0 else np.nan
        pnl_median = acc["median_sum"] / median_n if median_n > 0 else np.nan

        if variance_n > 1:
            variance_mean = acc["variance_mean_sum"] / variance_n
            numerator = acc["variance_second_sum"] - variance_n * variance_mean * variance_mean
            pnl_variance = numerator / (variance_n - 1.0)
        else:
            pnl_variance = np.nan
        pnl_stdev = np.sqrt(pnl_variance) if np.isfinite(pnl_variance) else np.nan

        rows.append(
            {
                "timeframe": timeframe,
                "direction_mode": direction,
                "rolling_window": window,
                "dimension_value": dim_value,
                "spread_bin": spread_bin,
                "norm_accel_bin": norm_accel_bin,
                "stop_band": stop_band,
                "target_band": target_band,
                "raw_n_count": acc["raw_n_count"],
                "pnl_mean": pnl_mean,
                "pnl_median": pnl_median,
                "pnl_variance": pnl_variance,
                "pnl_stdev": pnl_stdev,
                "pnl_mean_n_count": mean_n,
                "pnl_median_n_count": median_n,
                "pnl_variance_n_count": variance_n,
                "pnl_stdev_n_count": variance_n,
            }
        )
    return pd.DataFrame(rows)


def _band_mask(values, band):
    arr = np.asarray(values, dtype=np.float64)
    allowed = np.asarray(band, dtype=np.float64)
    if allowed.size == 0:
        return np.zeros(arr.shape, dtype=bool)
    return np.isclose(arr[:, np.newaxis], allowed[np.newaxis, :]).any(axis=1)


def build_aggregated_table(run_dir, dimension, packet):
    accumulators = defaultdict(_new_accumulator)
    paths = _parquet_paths(run_dir)
    if not paths:
        raise FileNotFoundError(f"No F*.parquet files found under {run_dir}")
    print(f"Discovered {len(paths)} parquet files under {run_dir}", flush=True)

    columns = [
        "pnl_mean",
        "pnl_median",
        "pnl_variance",
        "pnl_n_count",
        "stop_multiplier",
        "target_multiplier",
        "direction",
        "spread_bin",
        "norm_accel_bin",
    ]

    for i, path in enumerate(paths, start=1):
        if i == 1 or i % 250 == 0 or i == len(paths):
            print(f"Processing parquet {i}/{len(paths)}: {path}", flush=True)
        meta = _parse_path_metadata(path, run_dir)
        dim_value = meta[dimension]
        df = pq.read_table(path, columns=columns).to_pandas()

        mask = _band_mask(df["stop_multiplier"].to_numpy(), packet["stop_band"]) & _band_mask(
            df["target_multiplier"].to_numpy(), packet["target_band"]
        )
        df = df[mask]
        if df.empty:
            continue

        for row in df.itertuples(index=False):
            spread_bin = int(row.spread_bin)
            norm_accel_bin = int(row.norm_accel_bin)
            if spread_bin < 0 or norm_accel_bin < 0:
                continue

            direction = str(row.direction).strip()
            base_key = (
                meta["timeframe"],
                direction,
                meta["rolling_window"],
                dim_value,
                spread_bin,
                norm_accel_bin,
            )
            composite_key = (
                meta["timeframe"],
                "composite",
                meta["rolling_window"],
                dim_value,
                spread_bin,
                norm_accel_bin,
            )
            row_dict = row._asdict()
            _update_accumulator(accumulators[base_key], row_dict)
            _update_accumulator(accumulators[composite_key], row_dict)

    print("Finalizing joint distribution table...", flush=True)
    return _finalize_accumulators(accumulators, packet)


def _metric_norm(values, metric):
    finite = np.asarray(values, dtype=np.float64)
    finite = finite[np.isfinite(finite)]
    if finite.size == 0:
        return Normalize(vmin=0.0, vmax=1.0)

    if metric in {"pnl_mean", "pnl_median"}:
        max_abs = float(np.nanmax(np.abs(finite)))
        if max_abs == 0:
            max_abs = 1.0
        return TwoSlopeNorm(vmin=-max_abs, vcenter=0.0, vmax=max_abs)

    vmin = float(np.nanmin(finite))
    vmax = float(np.nanmax(finite))
    if vmin == vmax:
        vmax = vmin + 1.0
    return Normalize(vmin=vmin, vmax=vmax)


def _metric_cmap(metric):
    if metric in {"pnl_mean", "pnl_median"}:
        return "RdYlGn"
    return "Blues"


def _joint_dist_output_dir(run_dir, dimension, timeframe):
    """analysis/joint_dist/<dimension>/<timeframe>m/"""
    return os.path.join(run_dir, "analysis", "joint_dist", dimension, f"{timeframe}m")


def _plot_grid(df, *, out_dir, timeframe, dimension, direction, metric, n_quantiles):
    sub = df[(df["timeframe"] == timeframe) & (df["direction_mode"] == direction)].copy()
    if sub.empty:
        return None

    windows = sorted(sub["rolling_window"].unique())
    dim_values = sorted(sub["dimension_value"].unique())
    n_rows = len(dim_values)
    n_cols = len(windows)

    fig_w = max(4.8 * n_cols, 9.0)
    fig_h = max(4.1 * n_rows, 5.0)
    fig, axes = plt.subplots(
        n_rows,
        n_cols,
        figsize=(fig_w, fig_h),
        squeeze=False,
        constrained_layout=True,
    )

    norm = _metric_norm(sub[metric].to_numpy(), metric)
    cmap = _metric_cmap(metric)
    image = None

    for r, dim_value in enumerate(dim_values):
        for c, window in enumerate(windows):
            ax = axes[r][c]
            cell = sub[
                (sub["dimension_value"] == dim_value)
                & (sub["rolling_window"] == window)
            ]

            value_grid = np.full((n_quantiles, n_quantiles), np.nan, dtype=np.float64)
            raw_n_grid = np.zeros((n_quantiles, n_quantiles), dtype=np.float64)

            for row in cell.itertuples(index=False):
                x = int(row.spread_bin)
                y = int(row.norm_accel_bin)
                if 0 <= x < n_quantiles and 0 <= y < n_quantiles:
                    value_grid[y, x] = float(getattr(row, metric))
                    raw_n_grid[y, x] = float(row.raw_n_count)

            image = ax.imshow(value_grid, cmap=cmap, norm=norm, aspect="auto", origin="lower")

            for y in range(n_quantiles):
                for x in range(n_quantiles):
                    val = value_grid[y, x]
                    n = raw_n_grid[y, x]
                    if np.isfinite(val):
                        label = f"{val:.3f}\nn={int(n)}"
                    elif n > 0:
                        label = f"nan\nn={int(n)}"
                    else:
                        label = ""
                    ax.text(x, y, label, ha="center", va="center", fontsize=5)

            ax.set_xticks(np.arange(n_quantiles))
            ax.set_yticks(np.arange(n_quantiles))
            ax.set_xticklabels([str(x) for x in range(n_quantiles)], fontsize=7)
            ax.set_yticklabels([str(y) for y in range(n_quantiles)], fontsize=7)

            if r == 0:
                ax.set_title(window, fontsize=9)
            if c == 0:
                ax.set_ylabel(f"{dimension}={dim_value}\nnorm_accel_bin", fontsize=9)
            if r == n_rows - 1:
                ax.set_xlabel("spread_bin", fontsize=9)

    title = (
        f"Joint quantile heatmaps | timeframe={timeframe}m | "
        f"dimension={dimension} | direction={direction} | metric={metric}"
    )
    fig.suptitle(title, fontsize=14)
    if image is not None:
        fig.colorbar(image, ax=axes, shrink=0.8, label=metric)

    os.makedirs(out_dir, exist_ok=True)
    out_path = os.path.join(out_dir, f"{direction}__{metric}.png")
    print(f"Saving image: {out_path}", flush=True)
    fig.savefig(out_path, dpi=225)
    plt.close(fig)
    return out_path


def main(run_dir, dimension, packet):
    if dimension not in VALID_DIMENSIONS:
        raise ValueError(f"dimension must be one of {sorted(VALID_DIMENSIONS)}, got {dimension!r}")

    run_dir = os.path.abspath(run_dir)
    params = _load_parameters()
    n_quantiles = int(params["n_quantiles"])

    df = build_aggregated_table(run_dir, dimension, packet)
    written = []
    for timeframe in sorted(df["timeframe"].unique()):
        out_dir = _joint_dist_output_dir(run_dir, dimension, int(timeframe))
        os.makedirs(out_dir, exist_ok=True)
        summary_path = os.path.join(out_dir, "aggregated.csv")
        df_csv = df[df["timeframe"] == timeframe].copy()
        for col in ("pnl_mean", "pnl_median", "pnl_variance", "pnl_stdev"):
            if col in df_csv.columns:
                df_csv[col] = df_csv[col].round(3)
        print(f"Saving aggregated CSV: {summary_path}", flush=True)
        df_csv.to_csv(summary_path, index=False)
        written.append(summary_path)

        for direction in DIRECTIONS:
            for metric in METRICS:
                print(f"Rendering {timeframe}m / {dimension} / {direction} / {metric}", flush=True)
                path = _plot_grid(
                    df,
                    out_dir=out_dir,
                    timeframe=int(timeframe),
                    dimension=dimension,
                    direction=direction,
                    metric=metric,
                    n_quantiles=n_quantiles,
                )
                if path is not None:
                    written.append(path)

    print("Wrote analysis outputs:")
    for path in written:
        print(path)


if __name__ == "__main__":
    if len(sys.argv) < 3:
        raise SystemExit(
            "Usage: python analysis/joint_dist.py <run_dir> <dimension>\n"
            "dimension: L_value | ATR_value | F_value"
        )

    packet = {
        "x": "spread_delta",
        "y": "norm_accel",
        "target_band": [0.5, 0.75],
        "stop_band": [1.75, 2.0, 2.25, 2.5],
    }
    main(sys.argv[1], sys.argv[2], packet)