# N-bar ordered structure (strict monotonic O/H/L/C), single sliding window over OHLC
import numpy as np
from numpy.lib.stride_tricks import sliding_window_view


def structure(data, n, direction):
    """
    Find bar indices where the last bar completes an n-candle strictly ordered run.

    long:  each of open, high, low, close strictly increases over the window.
    short: each strictly decreases.

    Parameters
    ----------
    data : (rows, >=5) array — columns 1–4 are O, H, L, C mid.
    n : int — window length (>=1).
    direction : "long" | "short"

    Returns
    -------
    np.ndarray intp — indices of the **closing** bar of each valid window (0-based).
    """
    n = int(n)
    dir = np.greater if direction == "long" else np.less
    if n < 1:
        raise ValueError("n must be >= 1")

    if direction not in ("long", "short"):
        raise ValueError('direction must be "long" or "short"')

    if data.ndim != 2 or data.shape[1] < 5 or data.shape[0] < n:
        return np.array([], dtype=np.intp)

    # shape (T - n + 1, 4, n): OHLC rows, then n closes along last axis
    ohlc = data[:, 1:5].astype(np.float64, copy=False)
    w = sliding_window_view(ohlc, n, axis=0)
    left, right = w[:, :, :-1], w[:, :, 1:]
    step_ok = (dir(right, left).all(axis=2)).all(axis=1)

    # enforce candle body direction across setup window
    open_w = w[:, 0, :]
    close_w = w[:, 3, :]
    body_ok = (close_w > open_w).all(axis=1) if direction == "long" else (close_w < open_w).all(axis=1)

    starts = np.flatnonzero(step_ok & body_ok)
    return (starts + (n - 1)).astype(np.intp, copy=False)
